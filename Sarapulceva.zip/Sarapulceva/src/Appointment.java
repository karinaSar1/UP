import java.util.ArrayList;

public class Appointment {
//  Свойства: пациент, врач, дата и время приема, описание проблемы
    private int id_zapis;
    private int id_pat;
    private int id_doc;
    private String date_pr;
    private String problem;
    private int id_res;
    private String name_res;
    private String surname_res;
    private String grep_res;

    public void addPath(int id_zapis, int id_pat, int id_doc, String date_pr,
                        String problem, ArrayList<Patient> Path){
        Patient patient = new Patient();
        patient.setId_pat(id_pat);
        patient.setId_zapis(id_zapis);
        patient.setId_doc(id_doc);
        patient.setDate_pr(date_pr);
        patient.setProblem(problem);
        Path.add(patient);
    }

    public void DelPath(int id_pat, ArrayList<Patient> Path){
        for (int i = 0; i<Path.size(); i++){
            if (id_pat == Path.get(i).getId_pat()){
                Path.remove(i);
            }
        }
    }
    public void addAdmin(int id_res, String name_res, String surname_res,
                         String grep_res, ArrayList<Receptionist> Admin) {
        Receptionist rec = new Receptionist();
        rec.setId_res(id_res);
        rec.setName_res(name_res);
        rec.setSurname_res(surname_res);
        rec.setGrep_res(grep_res);
        Admin.add(rec);
    }
    public void DelAdmin(int id_res, ArrayList<Receptionist> Admin){
        for (int i = 0; i<Admin.size(); i++){
            if (id_res == Admin.get(i).getId_res()){
                Admin.remove(i);
            }
        }
    }
    public void addZapis(int id_zapis, int id_pat, int id_doc,
                         String date_pr, String problem, ArrayList<Appointment> Zapis) {
        Appointment appointment = new Appointment();
        appointment.setId_zapis(id_zapis);
        appointment.setId_pat(id_pat);
        appointment.setId_doc(id_doc);
        appointment.setDate_pr(date_pr);
        appointment.setProblem(problem);
        Zapis.add(appointment);
    }
    public void DelZapis(int id_zapis, ArrayList<Appointment> Zapis){
        for (int i = 0; i<Zapis.size(); i++){
            if (id_zapis == Zapis.get(i).getId_zapis()){
                Zapis.remove(i);
            }
        }
    }

    public int getId_res() {
        return id_res;
    }

    public String getGrep_res() {
        return grep_res;
    }

    public String getName_res() {
        return name_res;
    }

    public String getSurname_res() {
        return surname_res;
    }

    public void setGrep_res(String grep_res) {
        this.grep_res = grep_res;
    }

    public void setId_res(int id_res) {
        this.id_res = id_res;
    }

    public void setName_res(String name_res) {
        this.name_res = name_res;
    }

    public void setSurname_res(String surname_res) {
        this.surname_res = surname_res;
    }
    public int getId_doc() {
        return id_doc;
    }

    public void setId_doc(int id_doc) {
        this.id_doc = id_doc;
    }

    public void setId_pat(int id_pat) {
        this.id_pat = id_pat;
    }

    public int getId_pat() {
        return id_pat;
    }

    public int getId_zapis() {
        return id_zapis;
    }

    public String getDate_pr() {
        return date_pr;
    }

    public String getProblem() {
        return problem;
    }

    public void setDate_pr(String date_pr) {
        this.date_pr = date_pr;
    }

    public void setId_zapis(int id_zapis) {
        this.id_zapis = id_zapis;
    }

    public void setProblem(String problem) {
        this.problem = problem;
    }
}
