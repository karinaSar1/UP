public class Receptionist {
//  Свойства: имя, фамилия, график работы
    private int id_res;
    private String name_res;
    private String surname_res;
    private String grep_res;



    public int getId_res() {
        return id_res;
    }

    public String getGrep_res() {
        return grep_res;
    }

    public String getName_res() {
        return name_res;
    }

    public String getSurname_res() {
        return surname_res;
    }

    public void setGrep_res(String grep_res) {
        this.grep_res = grep_res;
    }

    public void setId_res(int id_res) {
        this.id_res = id_res;
    }

    public void setName_res(String name_res) {
        this.name_res = name_res;
    }

    public void setSurname_res(String surname_res) {
        this.surname_res = surname_res;
    }
}
