public class MedicalRecord {

//- Свойства: пациент, диагноз, рецепты, результаты анализов и обследований
    private int id_pat;
    private String diag;
    private String recept;
    private String result;

//- Методы: добавление/изменение диагноза, добавление/изменение рецептов, добавление результатов анализов

    public int getId_pat() {
        return id_pat;
    }

    public void setId_pat(int id_pat) {
        this.id_pat = id_pat;
    }

    public String getDiag() {
        return diag;
    }

    public String getRecept() {
        return recept;
    }

    public String getResult() {
        return result;
    }

    public void setDiag(String diag) {
        this.diag = diag;
    }

    public void setRecept(String recept) {
        this.recept = recept;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
