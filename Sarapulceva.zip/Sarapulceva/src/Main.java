import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Main {
    static ArrayList<Receptionist> Admin = new ArrayList<>();
    static ArrayList<Patient> Path = new ArrayList<>();
    static ArrayList<Appointment> Zapis = new ArrayList<>();

    public static void main(String[] args) {
        Appointment app = new Appointment();
        app.addPath(1, 1, 1, "21.12.2024", "Головная боль", Path);
        app.addPath(2, 2, 2, "25.05.2024", "Тошнота", Path);
        app.addPath(3, 3, 2, "16.04.2024", "Боль в горле, температура", Path);
        System.out.println("Количество пациентов в базе: " + Path.size());
        System.out.println("Производится удаление пациента");
        app.DelPath(1, Path);
        System.out.println("Удаление успешно");
        System.out.println("Количество пациентов в базе: " + Path.size());

        app.addAdmin(1, "Кира", "Лебольд", "ПН-ВТ с 8:00 - 21:00", Admin);
        app.addAdmin(2, "Елена", "Яготина", "СР-ЧТ с 8:00 - 21:00", Admin);
        app.addAdmin(3, "Варвара", "Меньшикова", "ПТ-СБ с 8:00 - 21:00", Admin);
        System.out.println("Количество работников регистратуры нашей клиники: " + Admin.size());
        System.out.println("Производится увольнение работника");
        app.DelAdmin(1, Admin);
        System.out.println("Увольнение успешно");
        System.out.println("Количество работников регистратуры нашей клиники: " + Admin.size());

        app.addZapis(1, 1, 1, "21.12.2024", "Головная боль", Zapis );
        app.addZapis(2, 2, 2, "25.05.2024", "Тошнота", Zapis );
        app.addZapis(3, 3, 2, "16.04.2024", "Боль в горле, температура", Zapis );
        System.out.println("Количество актуальных записей: " + Zapis.size());
        System.out.println("Производится удаление записи");
        app.DelZapis(1, Zapis);
        System.out.println("Удаление успешно");
        System.out.println("Количество актуальных записей: " + Zapis.size());

        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите количество желаемых записей: ");

        int count = scanner.nextInt();
        int[] id_path = new int[count];
        int[] id_spech = new int[count];
        String[] date_pr = new String[count];
        String[] problem = new String[count];

        System.out.println("Введите данные для каждой записи:");
        for (int i = 0; i < count; i++) {

            System.out.print("Введите  id пациента " + (i+1) + ": ");
            id_path[i] = Integer.parseInt(scanner.next());

            System.out.print("Введите id врача специалиста " + (i+1) + ": ");
            id_spech[i] = Integer.parseInt(scanner.next());

            System.out.print("Введите дату приёма " + (i+1) + ": ");
            date_pr[i] = scanner.next();

            System.out.print("Введите причину обращения " + (i+1) + ": ");
            problem[i] = scanner.next();
        }

        System.out.println("Зарегистрированные талоны:");
        for (int i = 0; i < count; i++) {
            System.out.println("Запись " + (i+1) + ": Пациент - "  + id_path[i] + ", Врач - " + id_spech[i] + ", Дата приёма - " + date_pr[i] );
            System.out.println("Причина обращения - "+ problem[i]);
        }
        System.out.println("Количество зарегистрированных талонов: " + (Zapis.size() + count));
    }
}