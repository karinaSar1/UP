public class Doctor {

//- Свойства: имя, фамилия, специализация, график работы

    private int id_doc;
    private String name_doc;
    private String surname_doc;
    private String spech_doc;
    private String graf_doc;


//- Методы: просмотр записей пациентов, проведение приема, выписывание рецептов

    public String getGraf_doc() {
        return graf_doc;
    }
    public String getName_doc() {
        return name_doc;
    }

    public String getSpech_doc() {
        return spech_doc;
    }

    public String getSurname_doc() {
        return surname_doc;
    }

    public void setGraf_doc(String graf_doc) {
        this.graf_doc = graf_doc;
    }

    public void setName_doc(String name_doc) {
        this.name_doc = name_doc;
    }

    public void setSpech_doc(String spech_doc) {
        this.spech_doc = spech_doc;
    }

    public void setSurname_doc(String surname_doc) {
        this.surname_doc = surname_doc;
    }

    public void setId_doc(int id_doc) {
        this.id_doc = id_doc;
    }

    public int getId_doc() {
        return id_doc;
    }
}
