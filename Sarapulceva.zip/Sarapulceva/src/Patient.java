public class Patient {

//  Имя, фамилия, дата рождения, пол, контактная информация

    private int id_pat;
    private String name_pat;
    private String surname_pat;
    private String date_pat;
    private String pol_pat;
    private String kontact_pat;
    private int id_zapis;
    private int id_doc;
    private String date_pr;
    private String problem;


//  Запись на прием, отмена записи, получение информации о приеме

    public void setId_zapis(int id_zapis) {
        this.id_zapis = id_zapis;
    }

    public String getDate_pr() {
        return date_pr;
    }

    public void setDate_pr(String date_pr) {
        this.date_pr = date_pr;
    }

    public void setId_doc(int id_doc) {
        this.id_doc = id_doc;
    }

    public int getId_zapis() {
        return id_zapis;
    }

    public String getProblem() {
        return problem;
    }

    public int getId_doc() {
        return id_doc;
    }

    public void setProblem(String problem) {
        this.problem = problem;
    }

    public String getDate_pat() {
        return date_pat;
    }

    public String getKontact_pat() {
        return kontact_pat;
    }

    public String getName_pat() {
        return name_pat;
    }

    public String getPol_pat() {
        return pol_pat;
    }

    public String getSurname_pat() {
        return surname_pat;
    }

    public void setDate_pat(String date_pat) {
        this.date_pat = date_pat;
    }

    public void setPol_pat(String pol_pat) {
        this.pol_pat = pol_pat;
    }

    public void setKontact_pat(String kontact_pat) {
        this.kontact_pat = kontact_pat;
    }

    public void setName_pat(String name_pat) {
        this.name_pat = name_pat;
    }

    public void setSurname_pat(String surname_pat) {
        this.surname_pat = surname_pat;
    }

    public int getId_pat() {
        return id_pat;
    }

    public void setId_pat(int id_pat) {
        this.id_pat = id_pat;
    }
}
