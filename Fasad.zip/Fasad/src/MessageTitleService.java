public class MessageTitleService {
    public String getShortTitle(String userName, String messageTypeSms) {
        return null;
    }

    public String getFullTitle(String userName2, String messageTypeSms) {
        return null;
    }
}
