import java.time.LocalDateTime;
import java.util.UUID;

public class SmsDeliveryService {
    public void send(UUID UserId, String messageTitle, String messageText, LocalDateTime time){
    }
}
