import java.time.LocalDateTime;
import java.util.UUID;

public class EmailDeliveryService {
    public void send(UUID userId, String messageTitle2, String messageText2, LocalDateTime time2) {
    }
}
