import java.time.LocalDateTime;

public class SendingTimeService {
    public LocalDateTime getSendindTime(String messageTypeSms){
        return null;
    }

    public LocalDateTime getSendingTime(String messageTypeSms) {
        return null;
    }
}
