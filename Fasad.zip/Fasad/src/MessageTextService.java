public class MessageTextService {
    public String getShortText(String userName, String messageTypeSms) {
        return null;
    }

    public String getFullText(String userName2, String messageTypeSms) {
        return null;
    }
}
